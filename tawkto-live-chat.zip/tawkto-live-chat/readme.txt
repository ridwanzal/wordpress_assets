=== Tawk.To Live Chat ===
Contributors: tawkto
Tags: tawk,tawk.to,tawkto,chat,free chat,livechat,chat widget,plugin,chat for web,chat online,chat software,free live chat,IM Chat,,live chat,live support,live web chat,online chat,online support,snapengage,wordpress chat,wordpress live chat
Requires at least: 2.7
Tested up to: 5.5.1
Stable tag: 0.4.3

(OFFICIAL tawk.to plugin) Instantly chat with  visitors on your website with the free tawk.to chat widget.
Website: [http://tawk.to](http://tawk.to)
== Description ==

Over 3,800,000+ business users use the tawk.to FREE live chat app that lets you monitor and chat with visitors on your Wordpress site. No catch. No spam. No Ads. It's truly free and always will be.

tawk.to is the #1 most widely used chat applicationin the world.

* Gain valuable insight when you monitor your website visitors in real time.
* Stay connected anywhere, be in touch with your customers from your computer, or your mobile.
* Live Chat is convenient for your customers, helping them through pain points and as a result helping you generate better customer support and higher conversions.

[youtube https://www.youtube.com/watch?v=G7o8x5gj2ww]

tawk.to is designed to increase the effectiveness in managing the online customer engagement experience, enabling multiple websites and agents in a single dashboard interface to chat with the visitors on your website.

Compatible with all modern browsers, tawk.to is free live chat software created out of the growing need for businesses to respond in real time, with real people.

Tawk.to offers free iOS, Android, Windows and Mac OSX apps to stay connected, or you can log in via any modern browser.

= Why use tawk.to? =

tawk.to is a free live chat app which integrates seamlessly with Wordpress! More than 250000 companies use tawk.to to provide real time support and service to their customers. Never lose another lead or sale again, with tawk.to you can monitor and chat with your website visitors when they need it most.

= How much does this cost? =

This tawk.to app is completely free.

To learn why tawk.to is free visit [https://www.tawk.to/why-free/](https://www.tawk.to/why-free/)

= Support =

tawk.to offers 24x7-365 live support, visit https://www.tawk.to and initiate a chat or send us an email at support@tawk.to.

Don't have a tawk.to account ? [Create one for free here!](https://www.tawk.to/?utm_source=wpdirectory&utm_medium=link&utm_campaign=signup)

== Installation ==

Adding tawk.to live chat widget to your Wordpress site is really easy, follow these steps :

* Clone this repository into your plugins directory or download the zip file and unzip on your plugins directory
* or Install the Free plugin from the WordPress directory and activate it.
* Go to `Settings`, then to the `Tawk.to` sub menu, and login to your tawk.to account to select a widget.
* Customize the chat widget from within the [tawk.to dashboard](https://dashboard.tawk.to) to your preference.
* Start chatting with your visitors! :)

Note: You will need a free tawk.to account : [Create one for free here!](https://tawk.to/?utm_source=wpdirectory&utm_medium=link&utm_campaign=signup)

== Changelog ==

= 0.1.0 =
* Add the tawk.to live chat widget to your site!

= 0.1.1 =
* No more manual embed code copying, choose desired widget and it will be inserted in your site

= 0.1.2 =
* Supported version bump

= 0.1.3 =
* Supported version bump

= 0.1.4 =
* Supported version bump

= 0.1.5 =
* Implemented visibility options, you can now choose to Always show the script, show it only on the front page, only on category pages or only on pages tagged with a shortcode.

= 0.1.6 =
* Modified visibility options to fix a bug, and implemented a better shortcode.

= 0.1.7 =
* Fixed naming convention causing a conflict with another plugin

= 0.1.8 =
* Fixed bug causing conflict with another plugin, and tested on 4.5

= 0.1.9 =
* Added the ability to exclude a specific url slug

= 0.2.0 =
* Added multisite support *

= 0.2.1 =
* Supported version bump

= 0.2.2 =
* Supported version bump to 4.7

= 0.2.3 =
* Updating widget code due to known conflict

= 0.2.4 =
* updated session handling
* Added the ability to include a specific url slug
* modified plugin settings page interface

= 0.2.5 =
* Fixed include url warning message thrown

= 0.2.6 =
* wrapped all hard-coded text in plugin settings with gettext functions

= 0.2.7 =
* added woocommerce support

= 0.2.8 =
* added updated plugin admin interface

= 0.2.9 =
* fixed issue with assets folder

= 0.3.0 =
* fixed issues with visibility filters

= 0.3.0 =
* fixed issues with visibility filters

= 0.3.1 =
* plugin notifications update
* logged in user recognition
  If user is logged in, the widget will fill the pre-chat form automatically

= 0.3.2 =
* fixed issues on widget settings on fresh install

= 0.3.3 =
* fixed user recognition vulnerability
* updated admin page texts
* moved wp_footer hook to last item

= 0.3.4 =
* supported version bump

= 0.3.5 =
* supported version bump

= 0.3.6 =
* supported version bump 5.1

= 0.3.7 =
* supported version bump 5.2.1

= 0.3.8 =
* supported version bump 5.2.2

= 0.4.0 =
* Added support for wildcard url match for include URL and exclude URL

= 0.4.1 =
* Fixed plugin version mismatch in readme and plugin file

= 0.4.2 =
* supported version bump 5.4

= 0.4.3
* supported version bumbp 5.5.1

## Frequently Asked Questions

= How much does this cost? =

This tawk.to app is completely free.

= Do you provide support? =

Yes, we provide 24x7-365 real time support via both live chat and email. We never close.

= Can I choose which pages to put the widget on? =

Yes, you can use the visibility options in the Plugin settings to select specific pages, or you can show the tawk.to widget  on any page independent of the visibility options by simply using the [tawkto] shortcode in the post or page.

= Can I customize the widget design =

Yes, you can customize colors, content, border radius, position etc. You can even select one of 27 different languages, add Attention Grabbing bubbles etc.

= Can I schedule when the widget will be shown? =

Yes, there is a complete widget scheduler.

= Do you have any documentation or support articles? =

Yes, we have a very detailed Knowledge Base, which includes videos & tutorials on all the features of tawk.to [https://www.tawk.to/knowledgebase/](https://www.tawk.to/knowledgebase/)

= Can multiple users chat at one time? =

Yes, you can add an unlimited number of Agents to your account so that your entire team can chat with your website visitors. Tawk.to also has a Departments feature, to group your agents. Eg: Sales, Support etc.

